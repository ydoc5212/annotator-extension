chrome.action.onClicked.addListener(async e=>{if(e.id)try{await chrome.tabs.sendMessage(e.id,{type:"TOGGLE_ANNOTATOR"})}catch{chrome.tabs.reload(e.id)}});
